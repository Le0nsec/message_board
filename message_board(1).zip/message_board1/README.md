# 一个简易的登录留言板（一）
* 用户root 密码root
* 其他用户可以自行在sql中查找
* 数据库用户名:message 密码:message
* 使用前请先导入message_board.sql
> 目前为第一版本，存在xss和sql注入等漏洞，修补后更新第二版本